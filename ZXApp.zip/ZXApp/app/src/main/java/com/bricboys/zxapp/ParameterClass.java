package com.bricboys.zxapp;

public class ParameterClass {
    public static String parameter;
    public static final String pubSinclair = "https://archive.org/download/World_of_Spectrum_June_2017_Mirror/World%20of%20Spectrum%20June%202017%20Mirror.zip/World%20of%20Spectrum%20June%202017%20Mirror/sinclair/";
    public static final String zxdbSinclair = "https://spectrumcomputing.co.uk/zxdb/sinclair/";
}
